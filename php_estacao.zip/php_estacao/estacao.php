<?php
    header('Content-Type: text/html; charset=utf-8');

    //variaveis 
    $meses = $_POST["meses"];
 
    //teste se preencheu o formulario
     if(isset($_POST["meses"])){
        
     switch ($meses){
        case "janeiro":
            echo " <br>Mês escolhido foi janeiro";
            echo "<br>Estação: Verão";
            echo "<br> <img src='./img/verao.jpg'> <br>";
        break;

        case "fevereiro":
            echo "<br>Mês escolhido foi fevereiro";
            echo "<br>Estação: Verão";
            echo "<br> <img src='img/verao.jpg'>";
        break;

        case "março":
            echo "<br>Mês escolhido foi março";
            echo "<br>Estação: Verão";
            echo "<br> <img src='img/verao.jpg'> <br>";
        break;

        case "abril":
            echo "<br>Mês escolhido foi abril";
            echo "<br>Estação: Outono";
            echo "<br> <img src='img/outono.jpg'> <br>";
        break;

        case "maio":
            echo "<br>Mês escolhido foi maio";
            echo "<br>Estação: Outono";
            echo "<br> <img src='img/outono.jpg'> <br>";
        break;

        case "junho":
            echo "<br>Mês escolhido foi junho";
            echo "<br>Estação: Outono";
            echo "<br> <img src='img/outono.jpg'> <br>";
        break;

        case "julho":
            echo "<br>Mês escolhido foi julho";
            echo "<br>Estação: inverno";
            echo "<br> <img src='img/inverno.jpg'> <br>";
        break;

        case "agosto":
            echo "<br>Mês escolhido foi agosto";
            echo "<br>Estação: inverno";
            echo "<br> <img src='img/inverno.jpg'> <br>";
        break;

        case "setembro":
            echo "<br>Mês escolhido foi setembro";
            echo "<br>Estação: inverno";
            echo "<br> <img src='img/inverno.jpg'> <br>";
        break;

        case "outubro":
            echo "<br>Mês escolhido foi outubro";
            echo "<br>Estação: primavera";
            echo "<br> <img src='img/primavera.jpg'> <br>";
        break;

        case "novembro":
            echo "<br>Mês escolhido foi novembro";
            echo "<br>Estação: primavera";
            echo "<br> <img src='img/primavera.jpg'> <br>";
        break;

        case "dezembro":
            echo "<br>Mês escolhido foi dezembro ";
            echo "<br>Estação: primavera";
            echo "<br> <img src='img/primavera.jpg'> <br>";
        break;
        }

    }
    else{
        header("location:index.html");
    }
   
?>